import React from "react"
import { Row, Col, Button } from "reactstrap"
import ProfileHeader from "./ProfileHeader"
import AboutCard from "./AboutCard"
import SuggestedPages from "./SuggestedPages"
import Posts from "./Posts"
import Videos from "./Videos"
import { history } from "../../../../src/history"
import * as Icon from "react-feather"

import "../../../assets/scss/pages/users-profile.scss"

class SponsorDetails extends React.Component {
  state = {
    isLoading: false
  }

  toggleLoading = () => {
    this.setState({
      isLoading: true
    })

    setTimeout(() => {
      this.setState({
        isLoading: false
      })
    }, 2000)
  }

  render() {
    return (
      <React.Fragment>
        <div className="d-flex justify-content-between align-items-center flex-wrap">                        
      <h1 className="mt-1 mb-2">Sponsor Details</h1>
                        <div>
                          <Button.Ripple
                            className="unlock-btn"
                            color="primary"
                            onClick={() => history.push("/pages/sponsor")}
                          >
                           <Icon.Star size={14} className="mr-50" /> Exhibitor List
                          </Button.Ripple>
                        </div>
                      </div>
        <div id="user-profile">
          <Row>
            <Col sm="12">
              <ProfileHeader />
            </Col>
          </Row>
          <div id="profile-info">
            <Row>
              <Col lg="8" md="12">
                <AboutCard />
              </Col>
              <Col lg="4" md="12">
                <SuggestedPages />
              </Col>
              <Col lg="8" md="12">
                <Posts />
              </Col>
              <Col lg="4" md="12">
                <Videos />
              </Col>
            </Row>
          </div>
        </div>
      </React.Fragment>
    )
  }
}

export default SponsorDetails
