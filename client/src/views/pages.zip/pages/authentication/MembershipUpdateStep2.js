import React from "react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Row,
  Col,
  FormGroup,
  Form,
  Input,
  Button,
  Label
} from "reactstrap"
import banner from "../../../assets/img/pages/advbanner.jpg"
import { history } from "../../../history"
import "../../../assets/scss/pages/authentication.scss"
import axios from 'axios'
class ForgotPassword extends React.Component {

  state = {
    name: sessionStorage.getItem('mname'),
    esi: sessionStorage.getItem('mesi'),
    email: sessionStorage.getItem('memail'),
    otp: '',
    mobile: sessionStorage.getItem('mmobile'),
    message: ''
  }

  componentDidMount = () =>{
    if (sessionStorage.getItem('mmobile') == undefined) {
      history.push('/pages/updatemembership')
    }
  }

  handleUpdate = (e) => {
    e.preventDefault();

    if (sessionStorage.getItem('mmobile') != undefined) {
      const data = { otpval: this.state.otp, emailid: this.state.email, mobile: this.state.mobile };
      axios.post(`${process.env.REACT_APP_BASENAME}member/checkotp`, data).then(
        (response) => {
          console.log("response", response);
          if (response.data.status == true && response.data.flag == 1) {
            this.setState({
              message: response.data.message,
            })
            history.push('/pages/membershipupdatestep3')
          }
          else {
            this.setState({
              message: response.data.message,
            })
          }
        }
      ).catch((error) => {
        history.push('/pages/updatemembership')
      })
    }
    else {
      history.push('/pages/updatemembership')
    }

  }


  render() {
    return (
      <Row className="m-0 justify-content-center">
        <Col sm="10" xl="10" lg="10" md="8" className="justify-content-center" >
          <Card className="bg-authentication rounded-0 mb-0 w-100">
            <Row className="m-0">
              <Col
                lg="12"
                className="d-lg-block d-none text-center align-self-center"
              >
                <img src={banner} alt="fgImg" width="100%" />
              </Col>
              <Col lg="12" md="12" className="p-0">
                <Card className="rounded-0 mb-0 px-2 py-1">
                  <CardHeader className="pb-1">
                    <CardTitle>
                      <h4 className="mb-0">ESI Membership Update : Step 2</h4>
                    </CardTitle>
                  </CardHeader>
                  <CardBody className="pt-1 pb-0">
                  <span className="text-danger">{this.state.message}</span>
                    <Form onSubmit={this.handleUpdate}>
                      <Row>
                        <Col md="6" sm="12">
                          <FormGroup>
                            <Input type="hidden" value={this.state.mobile} />
                            <Label>Name</Label>
                            <Input type="text" placeholder="Name" value={this.state.name} readOnly={true} required />
                          </FormGroup>
                        </Col>
                        <Col md="6" sm="12">
                          <FormGroup>
                            <Label>ESI Membership No</Label>
                            <Input type="text" placeholder="ESI Membership No" value={this.state.esi} readOnly={true} required />
                          </FormGroup>
                        </Col>
                        <Col md="6" sm="12">
                          <FormGroup>
                            <Label> Email ID </Label>
                            <Input name="emailid" type="email" value={this.state.email} onChange={e => this.setState({ email: e.target.value })} required />
                          </FormGroup>
                        </Col>
                        <Col md="6" sm="12">
                          <FormGroup>
                            <Label>Submit OTP</Label>
                            <Input type="text" placeholder="Submit OTP" value={this.state.otp} onChange={e => this.setState({ otp: e.target.value })} required />
                          </FormGroup>
                        </Col>
                      </Row>
                      <div className="float-md-left d-block mb-1">
                        <Button.Ripple style={{ display: "none" }}> </Button.Ripple>
                      </div>
                      <div className="float-md-right d-block mb-1">
                        <Button.Ripple
                          color="primary"
                          type="submit"
                          className="px-75 btn-block"
                        >
                          Edit Records
                        </Button.Ripple>
                      </div>
                    </Form>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    )
  }
}
export default ForgotPassword
