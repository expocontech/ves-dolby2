import React from "react"
import Select from "react-select"
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Row,
  Col,
  FormGroup,
  Form,
  Input,
  Button,
  Label,
  ButtonDropdown, DropdownToggle, DropdownMenu, DropdownItem
} from "reactstrap"
import banner from "../../../assets/img/pages/advbanner.jpg"
import { history } from "../../../history"
import "../../../assets/scss/pages/authentication.scss"
import axios from "axios"

class ForgotPassword extends React.Component {
  state = {
    mobile: sessionStorage.getItem('mmobile'),
    raddress: '',
    degree: '',
    institute: '',
    year: '',
    university: '',
    message: '',
    stateval: '',
    cv: null,
    photo: null,
    data: []
  }

  handleUpdateMs = (e) => {
    e.preventDefault();
    var data1 = new FormData();
    console.log(this.state.stateval)
    data1.append('mobile', this.state.mobile)
    data1.append('raddress', this.state.raddress)
    data1.append('stateval', this.state.stateval)
    data1.append('degree', this.state.degree)
    data1.append('institute', this.state.institute)
    data1.append('year', this.state.year)
    data1.append('university', this.state.university)
    data1.append('cv', this.state.cv)
    data1.append('photo', this.state.photo)

    // console.log(data1)
    const formHeaders = { 'content-type': 'multipart/form-data' }
    axios.post(`${process.env.REACT_APP_BASENAME}final/edit`, data1, { headers: formHeaders }).then(
      (response) => {
        if (response.data.status == true && response.data.flag == 1) {
          console.log(response.data.message)
          sessionStorage.setItem('member',response.data.result)
          const d =  response.data.result[0]
          console.log("final name" + d.name)
          sessionStorage.setItem('fname',d.name)
          sessionStorage.setItem('femail',d.email)
          sessionStorage.setItem('fraddress',d.raddress)
          sessionStorage.setItem('fdegree',d.degree)
          sessionStorage.setItem('fyear',d.year)
          sessionStorage.setItem('fesi',d.esi)
          sessionStorage.setItem('fmobile',d.mobile)
          sessionStorage.setItem('fstate',d.state)
          sessionStorage.setItem('funiversity',d.university)
          sessionStorage.setItem('finstitute',d.institute)

          this.setState({
            message: response.data.message,
            raddress: '',
            stateval: '',
            degree: '',
            institute: '',
            year: '',
            university: '',
            cv: '',
            photo: ''
          })

          history.push('/pages/summary')
        }
        else {
          this.setState({
            message: response.data.message
          })
        }
      }

    ).catch((error) => {

    })

  }


  componentDidMount = () => {
    if (sessionStorage.getItem('mmobile') != undefined) {


      axios.get(`${process.env.REACT_APP_BASENAME}member/state`).then(
        (response) => {
          if (response.data.status == true && response.data.flag == 1) {
            this.setState({
              data: response.data.result
            })
          }
          else {
            this.setState({
              message: "Some error with server"
            })
          }
        }

      ).catch((error) => {
        history.push('/')
      })
    }
    else {
      history.push('/')
    }
  }
  render() {

    const delegatetype = this.state.data
    return (
      <Row className="m-0 justify-content-center">
        <Col sm="10" xl="10" lg="10" md="8" className="justify-content-center" >
          <Card className="bg-authentication rounded-0 mb-0 w-100">
            <Row className="m-0">
              <Col
                lg="12"
                className="d-lg-block d-none text-center align-self-center"
              >
                <img src={banner} alt="fgImg" width="100%" />
              </Col>
              <Col lg="12" md="12" className="p-0">
                <Card className="rounded-0 mb-0 px-2 py-1">
                  <CardHeader className="pb-1">
                    <CardTitle>
                      <h4 className="mb-0">ESI Membership Update : Step 3</h4>
                    </CardTitle>
                  </CardHeader>
                  <CardBody className="pt-1 pb-0">
                    <span className="text-danger">{this.state.message}</span>
                    <Form onSubmit={this.handleUpdateMs} action="#">
                      <Row>

                        <Col md="8" sm="12" xs="6">
                          <FormGroup>
                            <Input type="hidden" value={this.state.mobile} />
                            <Label>Residential Address </Label>
                            <Input name="raddress" type="text"
                              value={this.state.raddress}
                              onChange={e => this.setState({ raddress: e.target.value })}
                              required />
                          </FormGroup>
                        </Col>
                        <Col md="4" sm="6" xs="6">
                          <FormGroup>
                            <Label for="type" >State</Label>
                            <Input type="select" className='form-control' value={this.state.stateval} onChange={e => this.setState({ stateval: e.target.value })}>
                              <option value="0">Select Item</option>
                              {this.state.data.length > 0 ? this.state.data.map((v) => <option value={v.name}>{v.name}</option>) : <option value='0'>--Select--</option>}
                            </Input>
                          </FormGroup>
                        </Col>
                        <Col md="4" sm="6" xs="6">
                          <FormGroup>
                            <Label> Degree </Label>
                            <Input name="degree" type="text"
                              value={this.state.degree}
                              onChange={e => this.setState({ degree: e.target.value })}
                              required />
                          </FormGroup>
                        </Col>
                        <Col md="4" sm="6" xs="6">
                          <FormGroup>
                            <Label> University </Label>
                            <Input name="university" type="text"
                              value={this.state.university}
                              onChange={e => this.setState({ university: e.target.value })}
                              required />
                          </FormGroup>
                        </Col>
                        <Col md="4" sm="6" xs="6">
                          <FormGroup>
                            <Label> Year </Label>
                            <Input name="year" type="number" min={0}
                              value={this.state.year}
                              onChange={e => this.setState({ year: e.target.value })}
                              required />
                          </FormGroup>
                        </Col>
                        <Col md="4" sm="6" xs="6">
                          <FormGroup>
                            <Label> Institute / Affiliation </Label>
                            <Input name="institute" type="text"
                              value={this.state.institute}
                              onChange={e => this.setState({ institute: e.target.value })}
                              required />
                          </FormGroup>
                        </Col>

                        <Col md="4" sm="6" xs="6">
                          <FormGroup>
                            <Label> Current CV </Label>
                            <Input type="file"
                              defaultValue={this.state.cv}
                              onChange={e => this.setState({ cv: e.target.files[0] })}
                              id="exampleCustomFileBrowser" name="cv" required style={{ border: "1px solid #d9d9d9", padding: "3px", borderRadius: "5px" }} />
                          </FormGroup>
                        </Col>

                        <Col md="4" sm="6" xs="6">
                          <FormGroup>
                            <Label> Photo (before 2 months ) </Label>
                            <Input type="file"
                              defaultValue={this.state.photo}
                              onChange={e => this.setState({ photo: e.target.files[0] })}
                              id="exampleCustomFileBrowser" name="photo" required style={{ border: "1px solid #d9d9d9", padding: "3px", borderRadius: "5px" }} />
                          </FormGroup>
                        </Col>

                      </Row>
                      <div className="float-md-left d-block mb-1">
                        <Button.Ripple style={{ display: "none" }}> </Button.Ripple>
                      </div>
                      <div className="float-md-right d-block mb-1">
                        <Button.Ripple
                          color="primary"
                          type="submit"
                          className="px-75 btn-block"
                        >
                          Update Records
                        </Button.Ripple>
                      </div>
                    </Form>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    )
  }
}
export default ForgotPassword
