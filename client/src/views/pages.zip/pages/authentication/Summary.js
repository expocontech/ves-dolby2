import React from "react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody, Table, Row, Col
} from "reactstrap"
import banner from "../../../assets/img/pages/advbanner.jpg"
import axios from "axios"
import { history } from "../../../history"

class Summary extends React.Component {

  state = {
    name: sessionStorage.getItem('fname'),
    mobile: sessionStorage.getItem('fmobile'),
    esi: sessionStorage.getItem('fesi'),
    email: sessionStorage.getItem('femail'),
    address: sessionStorage.getItem('fraddress'),
    stateval: sessionStorage.getItem('fstate'),
    degree: sessionStorage.getItem('fdegree'),
    university: sessionStorage.getItem('funiversity'),
    year: sessionStorage.getItem('fyear'),
    institute: sessionStorage.getItem('finstitute')
  }

  componentDidMount = () => {
    if (sessionStorage.getItem('fmobile') == undefined) {
      history.push('/')
    }
  }

  render() {
    return (
      <Row className="m-0 justify-content-center">
        <Col sm="10" xl="10" lg="10" md="8" className="justify-content-center" ><Row className="m-0">
          <Card className="bg-authentication rounded-0 mb-0 w-100">
            <Col lg="12" className="d-lg-block d-none text-center align-self-center">
              <img src={banner} alt="fgImg" width="100%" />
            </Col>
            <Col lg="12" md="12" className="p-0">
              <Card className="rounded-0 mb-0 px-2 py-1">
                <CardHeader className="pb-1">
                  <CardTitle>
                    <h4 className="mb-0">ESI Membership Update : Step Summary Page</h4>
                  </CardTitle>
                </CardHeader>
                <CardBody className="pt-1 pb-0">
                  <Table responsive>
                    <tbody>
                      <tr>
                        <th scope="row">Name</th>
                        <td>{this.state.name}</td>
                        <th scope="row">ESI Membership No</th>
                        <td>{this.state.esi}</td>
                      </tr>
                      <tr>
                        <th scope="row">Email Id</th>
                        <td>{this.state.email}</td>
                        <th scope="row">Mobile No</th>
                        <td>{this.state.mobile}</td>
                      </tr>
                      <tr>
                        <th scope="row">Address</th>
                        <td>{this.state.address}</td>
                        <th scope="row">State</th>
                        <td>{this.state.stateval}</td>
                      </tr>
                      <tr>
                        <th scope="row">Degree</th>
                        <td>{this.state.degree}</td>
                        <th scope="row">University</th>
                        <td>{this.state.university}</td>
                      </tr>
                      <tr>
                        <th scope="row">Years</th>
                        <td>{this.state.year}</td>
                        <th scope="row">Institute / Affiliation</th>
                        <td>{this.state.institute}</td>
                      </tr>
                    </tbody>
                  </Table></CardBody>
              </Card></Col></Card></Row>
        </Col>
      </Row>
    )
  }
}
export default Summary
