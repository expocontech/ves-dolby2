import React from "react"
import { Form, FormGroup, Input, Label, Button, Row, Col } from "reactstrap"
import Checkbox from "../../../../components/@vuexy/checkbox/CheckboxesVuexy"
import { Check } from "react-feather"
import { connect } from "react-redux"
//import { signupWithJWT } from "../../../../redux/actions/auth/registerActions"
import { history } from "../../../../history"
import axios from "axios"


class SignupForm extends React.Component {
  state = {
    email: "",
    name: "",
    designation: "",
    institute: "",
    mobile: "",
    weburl: '',
    fmessage: '',
    rmessage: '',
    gtmwstatus: ''

  }
  componentDidMount = () => {
    axios.get(`${process.env.REACT_APP_BASENAME}eventsetting`).then(
      // history.push('/pages/liveview')
      (response) => {
        var gtmwstat
        if (response.data.gtmwbutton == 1) {
          gtmwstat = true
        }
        else {
          gtmwstat = false
        }
        console.log("response", response);
        if (response.data.status == true) {
          this.setState({
            weburl: response.data.weburl,
            gtmwstatus: gtmwstat
          })
        }

      }

    ).catch((error) => {
      history.push('/')
      this.setState({
        message: "Some error in login"
      })
    })
  }

  handleRegister = (e) => {
    e.preventDefault();
    console.log("Register called");
    const data = {
      email: this.state.email, name: this.state.name,
      designation: this.state.designation, institute: this.state.institute, mobile: this.state.mobile
    };

    axios.post(`${process.env.REACT_APP_BASENAME}signup`, data).then(
      (response) => {
        console.log("response", response);
        // history.push('/')
        if (response.data.status == true && response.data.flag == 1) {
          sessionStorage.setItem('remail', this.state.email);
          sessionStorage.setItem('rstatus', "Registered Successfully, Please Login!");
          history.push('/');
        }
        else {
          this.setState({
            'fmessage': "Not Registered"
          })
        }

      }
    ).catch((error) => {
      history.push('/');
    })

  }

  checkEmail = (emailval) => {
    console.log(`Email ${emailval}`);
    if (emailval == '') {
      document.getElementById('txtemail').focus();
      this.setState({
        fmessage: "Email must required",
        rmessage: ''
      })
    }
    else {
      axios.get(`${process.env.REACT_APP_BASENAME}signup/${emailval}`).then(
        response => {
          console.log(response.data);
          if (response.data.flag != 1) {
            console.log("In condiition")
            // email.focus();
            document.getElementById('txtemail').focus();
            this.setState({
              fmessage: response.data.message,
              rmessage: '',
              email: ''
            })
          }
          else {
            this.setState({
              rmessage: response.data.message,
              fmessage: ''
            })
          }


        }
      ).catch((error) => {

      });
    }
  }
  render() {
    return (
      <Form action="/" onSubmit={this.handleRegister}>
        <span className="text-danger">{this.state.fmessage}</span>
        <span className="text-success">{this.state.rmessage}</span>
        <FormGroup className="form-label-group">
          <Input
            type="text"
            placeholder="Name"
            required
            value={this.state.name}
            onChange={e => this.setState({ name: e.target.value })}
          />
          <Label>Name</Label>
        </FormGroup>
        <FormGroup className="form-label-group">
          <Input
            type="text"
            placeholder="Designation"
            required
            value={this.state.designation}
            onChange={e => this.setState({ designation: e.target.value })}
          />
          <Label>Designation</Label>
        </FormGroup>
        <FormGroup className="form-label-group">
          <Input
            type="text"
            placeholder="Institute"
            required
            value={this.state.institute}
            onChange={e => this.setState({ institute: e.target.value })}
          />
          <Label>Institute</Label>
        </FormGroup>
        <FormGroup className="form-label-group">
          <Input
            type="email"
            id="txtemail"
            placeholder="Email"
            required
            value={this.state.email}
            onBlur={() => this.checkEmail(this.state.email)}
            onChange={e => this.setState({ email: e.target.value })}
          />
          <Label>Email</Label>
        </FormGroup>
        <FormGroup className="form-label-group">
          <Input
            type="number"
            placeholder="Mobile No"
            required
            value={this.state.mobile}
            onChange={e => this.setState({ mobile: e.target.value })}
          />
          <Label>Mobile No</Label>
        </FormGroup>
        {/* <Col md="6" sm="12">
            <FormGroup className="form-label-group">
              <Input
                type="password"
                placeholder="Password"
                required
                value={this.state.password}
                onChange={e => this.setState({ password: e.target.value })}
              />
              <Label>Password</Label>
            </FormGroup>
          </Col> */}
        <Row>
          <Col md="12" sm="12">
            <FormGroup>
              <Checkbox
                color="primary"
                icon={<Check className="vx-icon" size={16} />}
                label=" I accept the terms & conditions."
                defaultChecked={true}
              />
            </FormGroup>
          </Col>
          <Col md="12" sm="12">
            <div className="d-flex justify-content-between">
              <Button.Ripple
                color="primary"
                outline
                onClick={() => {
                  history.push("/")
                }}
              >
                Login
          </Button.Ripple>
              <Button.Ripple color="primary" type="submit">
                Register
          </Button.Ripple>
            </div>
          </Col>
        </Row>
        {this.state.gtmwstatus ? <div className="d-flex justify-content-between">
          <Col sm="12" xl="12" lg="12" md="12" style={{ textAlign: "center" }}>
            <a href={this.state.weburl} className="btn btn-success" target="_blank" style={{ marginTop: "20px" }}>
              Go to main website!</a></Col>
        </div> : null}

      </Form>
    )
  }
}
export default SignupForm
