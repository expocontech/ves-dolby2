import React from "react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Row,
  Col,
  FormGroup,
  Form,
  Input,
  Button,
  Label
} from "reactstrap"
import banner from "../../../assets/img/pages/advbanner.jpg"
import { history } from "../../../history"
import "../../../assets/scss/pages/authentication.scss"
import axios from "axios"

class MobileValidate extends React.Component {
  state = {
    logo: '',
    mobile: '',
    message: ''
  }
  componentDidMount = () => {
    axios.get(`${process.env.REACT_APP_BASENAME}eventsetting`).then(
      (response) => {
        console.log("response", response);
        if (response.data.status == true) {
          this.setState({
            logo: `${process.env.REACT_APP_BASENAME}` + response.data.logo,
          })
        }
      }
    ).catch((error) => {
      history.push('/')
      this.setState({
        message: "Some error in login"
      })
    })
  }
  validateMobile = (e) => {
    e.preventDefault();
    console.log("Validate Mobile No called");
    const data = { mobile: this.state.mobile };
    axios.post(`${process.env.REACT_APP_BASENAME}member/validate`, data).then(
      (response) => {
        console.log("response", response.data);

        if (response.data.status == true && response.data.flag == 1) {
          this.setState({
            message: response.data.message,
          })
          sessionStorage.setItem('mname', response.data.result[0].name)
          sessionStorage.setItem('mesi', response.data.result[0].esi)
          sessionStorage.setItem('mmobile', response.data.result[0].mobile)
          sessionStorage.setItem('memail', response.data.result[0].email)
          history.push('/pages/membershipupdatestep2')
        }
        else {
          if (response.data.status == true) {
            this.setState({
              message: response.data.message,
              mobile: ''
            })
          }
        }
      }
    ).catch((error) => {
      history.push('/')
      this.setState({
        message: "Some error in server"
      })
    })
  }
  render() {
    return (
      <Row className="m-0 justify-content-center">
        <Col
          sm="8"
          xl="7"
          lg="10"
          md="8"
          className="d-flex justify-content-center"
        >
          <Card className="bg-authentication rounded-0 mb-0 w-100">
            <Row className="m-0">
              <Col
                lg="12"
                className="d-lg-block d-none text-center align-self-center"
              >
                <img src={banner} alt="esibanner" width="100%" />
                {/* <img src={this.state.logo} alt="fgImg" /> */}
              </Col>
              <Col lg="12" md="12" className="p-0">
                <Card className="rounded-0 mb-0 px-2 py-1">
                  <CardHeader className="pb-1">
                    <CardTitle>
                      <h4 className="mb-0">Please Enter Your Registered Mobile No.</h4>
                    </CardTitle>
                  </CardHeader>

                  <span className="text-danger">{this.state.message}</span>
                  <CardBody className="pt-1 pb-0">
                    <Form onSubmit={this.validateMobile} action="/pages/updatemembership">
                      <FormGroup className="form-label-group">
                        <Input type="text" placeholder="Enter Mobile No." value={this.state.mobile}
                          onChange={e => this.setState({ mobile: e.target.value })}
                          required />
                        <Label>Mobile No</Label>
                      </FormGroup>

                      <div className="float-md-left d-block mb-1">
                        <Button.Ripple style={{ display: "none" }}></Button.Ripple>
                      </div>
                      <div className="float-md-right d-block mb-1">
                        <Button.Ripple
                          color="primary"
                          type="submit"
                          className="px-75 btn-block"
                        >
                          Validate Membership
                        </Button.Ripple>

                      </div>
                      <p className="px-2 auth-title">
                        If records not found please email us at mailesisecretariat@gmail.com with your details to validate.
                  </p>
                    </Form>
                  </CardBody>
                </Card>
              </Col>
            </Row>
          </Card>
        </Col>
      </Row>
    )
  }
}
export default MobileValidate
