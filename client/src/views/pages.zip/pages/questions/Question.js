import React from "react"
import { Row, Col, Card, CardBody } from "reactstrap"
// import ExtensionsHeader from "../../../extensions/extensionsHeader"
import QuestionView from "./QuestionView"

class Question extends React.Component {
  render() {
    return (
      <React.Fragment>
          {/* <Card className="mt-1">
            <CardBody className="knowledge-base-bg">
              <h1 className="white">Question View</h1>
            </CardBody>
          </Card> */}
      {/* <ExtensionsHeader
        title="Question View"
      /> */}
        <Row>
          <Col sm="12">
            <QuestionView />
          </Col>
        </Row>
      </React.Fragment>
    )
  }
}

export default Question
