// import React from "react"
// import {
//   Form,
//   Modal,
//   ModalHeader,
//   ModalBody,
//   ModalFooter,
//   Card,
//   CardBody,
//   Button,
//   Input,
//   Row,
//   Col,
//   UncontrolledDropdown,
//   Label,
//   FormGroup,
//   DropdownMenu,
//   DropdownItem,
//   DropdownToggle
// } from "reactstrap"
// import axios from "axios"
// import { ContextLayout } from "../../../utility/context/Layout"
// import { AgGridReact } from "ag-grid-react"
// import {
//   ChevronDown
// } from "react-feather"
// import profileImg from "../../../assets/img/profile/user-uploads/user-01.jpg"
// import "../../../assets/scss/plugins/tables/_agGridStyleOverride.scss"
// import "../../../assets/scss/pages/users.scss"
// import banner from "../../../assets/img/logo/banner.jpg"
// import QuestionsList from "./QuestionsList"
// class LiveView extends React.Component {

//   state = {
//     modal: false,
//     data: [],
//     question: null
//   }

//   toggleModal = () => {
//     this.setState(prevState => ({
//       modal: !prevState.modal
//     }))
//   }
//   componentDidMount() {
//     // const authHeader = {'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString()};
//     // fetch('http://localhost:8080/viewlive/', {headers: authHeader}).then(results => {
//     //   return results.json();
//     // }).then(data => {
//     //     console.log(data);
//     //     this.setState({
//     //       data: data.result[0].livelink
//     //     });
//     // })
//     this.fetchQue()
//   }

//   fetchQue = () => {
//     const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
//     fetch('${process.env.REACT_APP_BASENAME}viewlive/', { headers: authHeader }).then(results => {
//       return results.json();
//     }).then(data => {
//       console.log(data);
//       this.setState({
//         data: data.result[0].livelink,
//         banner: "../../../assets/img/logo/" + data.result[0].livebanner
//       });
//     })
//   }
//   handleAddQuestion = () => {
//     const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
//     const uid = sessionStorage.getItem('uid').toString();
//     const data = { "uidval": uid, "questionval": this.state.question };
//     //console.log(this.state.question);
//     axios.post('${process.env.REACT_APP_BASENAME}viewlive/askquestion', data, { headers: authHeader }).then(
//       (response) => {
//         console.log("response", response);
//         this.fetchQue()
//       }
//     ).catch((error) => {

//     })
//   }
//   handleQuestion = (event) => {
//     this.setState({
//       question: event.target.value
//     });
//   }

//   render() {
//     const { rowData, columnDefs, defaultColDef, pageSize, data, banner } = this.state
//     return (
//       <Row className="app-user-list">

//         <Col sm="12" className="mb-2">
//           <img src={banner} width="100%" />
//         </Col>

//         {/* src="https://www.youtube.com/embed/3dSXSkWmJ24" */}
//         <Col sm="7">
//           <Card className="overflow-hidden">
//             <CardBody className="text-center">
//               <div className="embed-responsive embed-responsive-16by9">
//                 <iframe
//                   width="100%"
//                   height="250"
//                   src={data}
//                   frameBorder="0"
//                   allow="accelerometer autoplay encrypted-media gyroscope picture-in-picture"
//                   allowFullScreen
//                   title="video"
//                 />
//               </div>
//             </CardBody>
//           </Card>
//         </Col>
//         <Col sm="5">
//           <Card>
//             <CardBody>

//               <fieldset className="form-label-group mb-50">
//                 <Input
//                   type="textarea"
//                   rows="11"
//                   placeholder="Ask a Questions"
//                   id="add-comment"
//                   onChange={this.handleQuestion}
//                 />
//                 <Label for="add-comment"></Label>
//               </fieldset>
//               <Button.Ripple color="success" onClick={this.handleAddQuestion}>
//                 Ask a question
//             </Button.Ripple>
//             </CardBody>
//           </Card>
//         </Col>

//         <Col sm="12">
//           <QuestionsList />
//         </Col>

//       </Row>
//     )
//   }
// }

// export default LiveView
import React from "react"
import {
  Form,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Card,
  CardBody,
  Button,
  Input,
  Row,
  Col,
  UncontrolledDropdown,
  Label,
  FormGroup,
  DropdownMenu,
  DropdownItem,
  DropdownToggle
} from "reactstrap"
import axios from "axios"
import { ContextLayout } from "../../../utility/context/Layout"
import { AgGridReact } from "ag-grid-react"
import {
  ChevronDown
} from "react-feather"
import profileImg from "../../../assets/img/profile/user-uploads/user-01.jpg"
import "../../../assets/scss/plugins/tables/_agGridStyleOverride.scss"
import "../../../assets/scss/pages/users.scss"
import { history } from "../../../../src/history"
//import banner from "../../../assets/img/logo/banner.jpg"
import QuestionsList from "./QuestionsList"
// import { withRouter } from "react-router-dom";
class QuestionView extends React.Component {


  state = {
    modal: false,
    data: [],
    question: ''
  }

  toggleModal = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }))
  }
  componentDidMount() {
    console.log("question state", this.state.question)
    console.log("After question submit redirect");
    if (sessionStorage.getItem('token') != null) {
      const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
      fetch(`${process.env.REACT_APP_BASENAME}viewlive/`, { headers: authHeader }).then(results => {
        return results.json();
      }).then(data => {
        console.log(data);
        this.setState({
          link: data.result[0].livelink,
          banner: `${process.env.REACT_APP_BASENAME}` + data.result[0].livebanner
        });
      })
    }
    else {
      history.push('/')
    }
  }

  handleAddQuestion = (e) => {
    e.preventDefault();
    console.log("Handle Add question")
    const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
    const uid = sessionStorage.getItem('uid').toString();
    const data = { "uidval": uid, "questionval": this.state.question };

    axios.post(`${process.env.REACT_APP_BASENAME}viewlive/askquestion`, data, { headers: authHeader }).then(
      (response) => {
        console.log("response", response);
        this.setState({
          question : ' '
        })
      }
    ).catch((error) => {
      console.log("error", error);
    })

  }

  // handleQuestion = (event) => {
  //   this.setState({
  //     question: event.target.value
  //   });
  // }

  render() {
    const { rowData, columnDefs, defaultColDef, pageSize, link, banner } = this.state
    const name = sessionStorage.getItem('name')
    const institute = sessionStorage.getItem('institute')
    return (
      <Row className="app-user-list">
        {/* <Col sm="7">
          <Card className="overflow-hidden">
            <CardBody className="text-center">
              <div className="embed-responsive embed-responsive-16by9">
                <iframe
                  width="100%"
                  height="250"
                  src={link}
                  frameBorder="0"
                  allow="accelerometer autoplay encrypted-media gyroscope picture-in-picture"
                  allowFullScreen
                  title="video"
                />
              </div>
            </CardBody>
          </Card>
        </Col>
        <Col sm="5">
          <Card>
            <Form action="/pages/liveview" onSubmit={this.handleAddQuestion}>
              <CardBody>
                <div className="d-flex justify-content-start align-items-center mb-1">
                  <div className="user-page-info">
                    <p className="mb-0">{name}</p>
                    <span className="font-small-2">{institute}</span>
                  </div>
                </div>

                <fieldset className="form-label-group mb-50">
                  <Input
                    type="textarea"
                    rows="11"
                    placeholder="Ask a Questions"
                    id="add-comment"
                    value = {this.state.question}
                    onChange={e => this.setState({ question: e.target.value })}
                  />
                  <Label for="add-comment"></Label>
                </fieldset>
                <Button.Ripple color="success" type="submit">
                  Ask a question
            </Button.Ripple>
              </CardBody>
            </Form>
          </Card>
        </Col> */}

        <Col sm="12">
          <QuestionsList />
        </Col>

      </Row>
    )
  }
}

export default QuestionView
