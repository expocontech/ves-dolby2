import img1 from "../../../assets/img/pages/committee/Jayaprakashsai.jpg"
import img2 from "../../../assets/img/pages/committee/Vasanth.jpg"
import img3 from "../../../assets/img/pages/committee/Srinivas.jpg"
import img4 from "../../../assets/img/pages/committee/Prashanti.jpg"
import img5 from "../../../assets/img/pages/committee/Sadhana.jpg"
import img6 from "../../../assets/img/pages/committee/Manjunath.jpg"
import img7 from "../../../assets/img/pages/committee/Sanjay.jpg"

export const data = [
  {
    id: 1,
    img: img1,
    title: "dr. j. jayaprakashsai",
    text: "Founder / General Secretary"
  },
  {
    id: 2,
    img: img2,
    title: "dr. ch. vasanth kumar",
    text: "President"
  },
  {
    id: 3,
    img: img3,
    title: "dr. s. srinivas",
    text: "Vice President"
  },
  {
    id: 4,
    img: img4,
    title: "dr. p. krishna prashanti",
    text: "Treasurer"
  },
  {
    id: 5,
    img: img5,
    title: "dr. v. j. sadhana",
    text: "Jt. Secretary"
  },
  {
    id: 6,
    img: img6,
    title: "dr. manjunath anakal",
    text: "Executive Member"
  },
  {
    id: 7,
    img: img7,
    title: "dr. sanjay kambar",
    text: "Executive Member"
  }
]
