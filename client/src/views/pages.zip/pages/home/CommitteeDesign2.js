import React from "react"
import { Card, CardBody, Row, Col } from "reactstrap"
// import { Link } from "react-router-dom"
import { data } from "./CommitteeData2"
import axios from "axios";
import { history } from "../../../history"

class CommitteeDesign2 extends React.Component {

  state = {
    data : []
  }

  componentDidMount = () =>{
    if (sessionStorage.getItem('token') != null) {
      const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
      axios.get(`${process.env.REACT_APP_BASENAME}home/heacom`, { headers: authHeader }).then(
        response => {
          console.log(response.data);
          this.setState({
            data: response.data.result
          });
        }
      ).catch((error) => {

      });
    }
    else {
      history.push('/')
    }
  }


  renderCards = () => {
    let result = this.state.data.map(item => {
      if (this.props.value.length < 1) {
        return (
          <Col md="3" sm="12" xs="12" className="search-content" key={item.id}>
            <Card>
              <CardBody className="text-center">
                  <img
                    src={`${process.env.REACT_APP_BASENAME}`+item.img}
                    alt={item.name}
                    className="mx-auto mb-2"
                    width="100%"
                  />
                  <h5>{item.name.toUpperCase()}</h5>
                  <p className="text-dark">{item.city}</p>
              </CardBody>
            </Card>
          </Col>
        )
      } else if (item.name.includes(this.props.value)) {
        return (
          <Col md="3" sm="12" xs="12" className="search-content" key={item.id}>
            <Card>
              <CardBody className="text-center">
                  <img
                    src={`${process.env.REACT_APP_BASENAME}`+item.img}
                    alt={item.name}
                    className="mx-auto mb-2"
                    width="100%"
                  />
                  <h5>{item.name.toUpperCase()}</h5>
                  <p className="text-dark">{item.city}</p>
              </CardBody>
            </Card>
          </Col>
        )
      }
      return ""
    })
    return result
  }
  render() {
    return <Row>{this.renderCards()}</Row>
  }
}
export default CommitteeDesign2
