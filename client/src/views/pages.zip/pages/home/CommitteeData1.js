import img1 from "../../../assets/img/pages/committee/Bansi.jpg"
import img2 from "../../../assets/img/pages/committee/Jothydev.jpg"
import img3 from "../../../assets/img/pages/committee/Manoj.jpg"
import img4 from "../../../assets/img/pages/committee/Ashish.jpg"
import img5 from "../../../assets/img/pages/committee/Vinaykumar.jpg"
import img6 from "../../../assets/img/pages/committee/Sambit.jpg"
import img7 from "../../../assets/img/pages/committee/Sahay.jpg"
import img8 from "../../../assets/img/pages/committee/Jayanthy.jpg"
import img9 from "../../../assets/img/pages/committee/Santosh.jpg"
import img10 from "../../../assets/img/pages/committee/Srirang.jpg"

export const data = [
  {
    id: 1,
    img: img1,
    title: "dr. banshi saboo",
    text: "Ahmedabad"
  },
  {
    id: 2,
    img: img2,
    title: "dr. jothydev kesavadev",
    text: "Trivandrum"
  },
  {
    id: 3,
    img: img3,
    title: "dr. manoj chawla",
    text: "Mumbai"
  },
  {
    id: 4,
    img: img4,
    title: "dr. ashish dengra",
    text: "Jabalpur"
  },
  {
    id: 5,
    img: img5,
    title: "dr. vinay kumar d",
    text: "Ranchi"
  },
  {
    id: 6,
    img: img6,
    title: "dr. sambit das",
    text: "Bhubaneswar"
  },
  {
    id: 7,
    img: img7,
    title: "dr. rakesh sahay",
    text: "Hyderabad"
  },
  {
    id: 8,
    img: img8,
    title: "dr. jayanthy ramesh",
    text: "Vizag"
  },
  {
    id: 9,
    img: img9,
    title: "dr. r santosh",
    text: "Hyderabad"
  },
  {
    id: 10,
    img: img10,
    title: "dr. srirang abkari",
    text: "Hyderabad"
  }
]
