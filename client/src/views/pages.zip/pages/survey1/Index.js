import React from "react"
//import ExtensionsHeader from "../../../extensions/extensionsHeader"
//import { Row, Col } from "reactstrap"
import Survey from "./Survey1"
import "swiper/css/swiper.css"
import "../../../assets/scss/plugins/extensions/swiper.scss"
class Index extends React.Component {
  render() {
    return (
      <React.Fragment>
            <Survey />
      </React.Fragment>
    )
  }
}

export default Index
