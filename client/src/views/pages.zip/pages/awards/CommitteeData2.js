import img1 from "../../../assets/img/pages/committee/Mohan.jpg"
import img2 from "../../../assets/img/pages/committee/Shashank.jpg"
import img3 from "../../../assets/img/pages/committee/Bansi.jpg"
import img4 from "../../../assets/img/pages/committee/Manoj.jpg"

export const data = [
  {
    id: 1,
    img: img1,
    title: "dr. v. mohan",
    text: "Clinical Research"
  },
  {
    id: 2,
    img: img2,
    title: "dr. r. shashank joshi",
    text: "Diabetes Education"
  },
  {
    id: 3,
    img: img3,
    title: "dr. banshi saboo",
    text: "Clinical Diabetology"
  },
  {
    id: 4,
    img: img4,
    title: "dr. manoj chawla",
    text: "Diabetes Technology"
  }
]
