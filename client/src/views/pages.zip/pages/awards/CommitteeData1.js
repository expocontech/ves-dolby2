import img1 from "../../../assets/img/pages/sponsor/usv.png"
import img2 from "../../../assets/img/pages/sponsor/sunpharma.png"
import img3 from "../../../assets/img/pages/sponsor/emcure.png"
import img4 from "../../../assets/img/pages/sponsor/eris.png"
import img5 from "../../../assets/img/pages/sponsor/glenmark.png"
import img6 from "../../../assets/img/pages/sponsor/ipca.png"
import img7 from "../../../assets/img/pages/sponsor/docphexus.png"
import img8 from "../../../assets/img/pages/sponsor/goqii.png"

export const data = [
  {
    id: 1,
    img: img1,
    title: "usv private limited",
    text: "Diabetes Education"
  },
  {
    id: 2,
    img: img2,
    title: "sun pharmaceutical industries ltd",
    text: "Clinical Diabetes"
  },
  {
    id: 3,
    img: img3,
    title: "emcure pharmaceuticals",
    text: "Diabetes Innovations"
  },
  {
    id: 4,
    img: img4,
    title: "eris lifesciences ltd",
    text: "Patient Care"
  },
  {
    id: 5,
    img: img5,
    title: "glenmark pharmaceuticals",
    text: "Diabetes Research"
  },
  {
    id: 6,
    img: img6,
    title: "ipca pharmaceuticals",
    text: "Community Service"
  },
  {
    id: 7,
    img: img7,
    title: "docplexus",
    text: "Medical Education"
  },
  {
    id: 8,
    img: img8,
    title: "goqii technologies pvt. ltd.",
    text: "Preventive Health Care"
  }
]
