import logo from "../../../assets/img/pages/sponsor/logo.png"
import banner from "../../../assets/img/logo/banner.jpg"
//import video from "https://www.youtube.com/embed/3dSXSkWmJ24"

export const data = [
  {
    id: 1,
    img: logo,
    title: "first announcement brochure",
    institute: "Diamond Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 2,
    img: logo,
    title: "second announcement brochure",
    institute: "Platimum Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 3,
    img: logo,
    title: "trade brochure",
    institute: "Gold Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  }
]
