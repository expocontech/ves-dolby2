import React from "react"
import Select from "react-select"
import {
  Form,
  Modal,
  ModalHeader,
  ModalBody,
  Card,
  CardBody,
  Button,
  Input,
  Row,
  Col,
  Label,
  FormGroup, Badge
} from "reactstrap"
import DataTable from "react-data-table-component"
import { Star, Search } from "react-feather"
// import SweetAlert from 'react-bootstrap-sweetalert';
import { FaThumbsUp, FaThumbsDown, FaUsers, FaRegQuestionCircle } from "react-icons/fa"
import { Link } from 'react-router-dom'
// import SubscribersGained from "../../ui-elements/cards/statistics/SubscriberGained"
// import RevenueGenerated from "../../ui-elements/cards/statistics/RevenueGenerated"
// import QuaterlySales from "../../ui-elements/cards/statistics/QuaterlySales"
// import OrdersReceived from "../../ui-elements/cards/statistics/OrdersReceived"
import StatisticsCard from "../../../components/@vuexy/statisticsCard/StatisticsCard"
import {history} from "../../../history"



const colourOptions = [
  { value: "", label: "--Select--" },
  { value: "read", label: "Read" },
  { value: "notread", label: "Not Read" }
]

const CustomHeader = props => {
  return (
    <div className="d-flex flex-wrap justify-content-between ">
      {/* <div className="add-new">
        <Button.Ripple color="primary">Add New</Button.Ripple>
      </div> */}
      <Input value={props.value} onChange={e => props.handleFilter(e)} placeholder="Search..." />
    </div>
  )
}

class QuestionsList extends React.Component {

  // state = {
  //   model:false,
  //   data: null
  // }
  state = {
    columns: [
      {
        name: "Name",
        selector: "name",
        sortable: true,
        minWidth: "200px",
        cell: row => (
          <p className="text-bold-500 mb-0">{row.name}</p>
        )
      },
      {
        name: "Question",
        selector: "question",
        sortable: true,
        minWidth: "500px",
        cell: row => (
          <p className="text-bold-500 mb-0">{row.question}</p>
        )
      },
      {
        name: "Date Created",
        selector: "datetime",
        sortable: true,
        cell: row => (
          <p className="text-bold-500 text-truncate mb-0">{row.datetime}</p>
        )
      },
      // {
      //   name: "Reg No",
      //   selector: "regno",
      //   sortable: true,
      //   minWidth: "100px",
      //   cell: row => (
      //     <p className="text-bold-500 mb-0">{row.regno}</p>
      //   )
      // },
      {
        name: "Email",
        selector: "email",
        sortable: true,
        minWidth: "250px",
        cell: row => (
          <p className="text-bold-500 text-truncate mb-0">{row.email}</p>
        )
      }
    ],
    // data: [
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-2.jpg"),
    //     name: "Mr. Alyss Lillecrop",
    //     email: "alillecrop0@twitpic.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin Therapy rtia: Focus on Indian Patient Centric Insulin Therapy",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "read"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-1.jpg"),
    //     name: "Shep Pentlow",
    //     email: "spentlow1@home.pl",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin Focus on Indian Patient Centric Insulin Therapy Focus on Indian Patient Centric Insulin Therapy",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "read"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-3.jpg"),
    //     name: "Gasper Morley",
    //     email: "gmorley2@chronoengine.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-4.jpg"),
    //     name: "Phaedra Jerrard",
    //     email: "pjerrard3@blogs.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-5.jpg"),
    //     name: "Conn Plose",
    //     email: "cplose4@geocities.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-6.jpg"),
    //     name: "Tootsie Brandsma",
    //     email: "tbrandsma5@theatlantic.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-8.jpg"),
    //     name: "Sibley Bum",
    //     email: "sbum6@sourceforge.net",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-7.jpg"),
    //     name: "Kristoffer Thew",
    //     email: "kthew7@amazon.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-26.jpg"),
    //     name: "Fay Hasard",
    //     email: "fhasard8@java.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-12.jpg"),
    //     name: "Tabby Abercrombie",
    //     email: "tabercrombie9@statcounter.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-10.jpg"),
    //     name: "	Stella Indruch",
    //     email: "sindruch1@mayoclinic.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-17.jpg"),
    //     name: "	Aron McNirlin",
    //     email: "amcnirlin2@samsung.com",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-20.jpg"),
    //     name: "Ange Trenholm",
    //     email: "atrenholm4@slideshare.net",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-14.jpg"),
    //     name: "Caterina Starkie",
    //     email: "cstarkie5@feedburner.com",
    //     regno: "DDS001",
    //     question: "qustion Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin answer",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-25.jpg"),
    //     name: "Hugibert McGeagh",
    //     email: "hmcgeaghf@smh.com.au",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   },
    //   {
    //     image: require("../../../assets/img/portrait/small/avatar-s-12.jpg"),
    //     name: "Hortensia Soaper",
    //     email: "hsoaperh@mapy.cz",
    //     regno: "DDS001",
    //     question: "Bridging Barriers to Therapeutic inertia: Focus on Indian Patient Centric Insulin",
    //     date_time: "16/06/2020 03.00 PM",
    //     status: "notread"
    //   }
    // ],
    data: [],
    filteredData: [],
    value: ""
  }

  componentDidMount() {

    if (sessionStorage.getItem('token') != null) {
      const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
      fetch(`${process.env.REACT_APP_BASENAME}viewlive/getlist`, { headers: authHeader }).then(results => {
        return results.json();
      }).then(data => {
        console.log(data);
        this.setState({
          data: data.result
        });
        console.log(this.state.data)
      })
    }
    else {
      history.push('/')
    }
  }

  toggleModal = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }))
  }





  handleFilter = e => {
    let value = e.target.value
    let data = this.state.data
    let filteredData = this.state.filteredData
    this.setState({ value })

    if (value.length) {
      filteredData = data.filter(item => {
        let startsWithCondition =
          item.name.toLowerCase().startsWith(value.toLowerCase()) ||
          item.datetime.toLowerCase().startsWith(value.toLowerCase()) ||
          item.email.toLowerCase().startsWith(value.toLowerCase()) ||
          // item.regno.toLowerCase().startsWith(value.toLowerCase()) ||
          item.question.toLowerCase().startsWith(value.toLowerCase())
        let includesCondition =
          item.name.toLowerCase().includes(value.toLowerCase()) ||
          item.datetime.toLowerCase().includes(value.toLowerCase()) ||
          item.email.toLowerCase().includes(value.toLowerCase()) ||
          // item.regno.toLowerCase().includes(value.toLowerCase()) ||
          item.question.toLowerCase().includes(value.toLowerCase())

        if (startsWithCondition) {
          return startsWithCondition
        } else if (!startsWithCondition && includesCondition) {
          return includesCondition
        } else return null
      })
      this.setState({ filteredData })
    }
  }

  render() {
    let { data, columns, value, filteredData } = this.state
    return (
      <Row>

        <Col>
          <Card>
            <CardBody>
              <CustomHeader value={value} handleFilter={this.handleFilter} />
            </CardBody>
          </Card>
          <Card>
            <CardBody className="rdt_Wrapper">
              <DataTable
                className="dataTable-custom"
                data={value.length ? filteredData : data}
                columns={columns}
                noHeader
                fixedHeaderScrollHeight="500px"
                pagination
              />
            </CardBody>

            <Modal
              isOpen={this.state.modal}
              toggle={this.toggleModal}
              className="modal-dialog-centered modal-lg"
            >
              <ModalHeader toggle={this.toggleModal}>
                Update Status
        </ModalHeader>
              <ModalBody>
                <Form>
                  <Row >

                    <Col md="12" sm="12">
                      <FormGroup>
                        <Label for="status">Stauts</Label>
                        <Select className="React" classNamePrefix="select" defaultValue={colourOptions[0]} name="status" options={colourOptions} />
                      </FormGroup>
                    </Col>
                    <Col md="12" sm="12">
                      <Button.Ripple className="" color="primary" type="submit">Submit</Button.Ripple>
                      <Button.Ripple color="warning" type="reset" className="ml-1">Reset</Button.Ripple>
                    </Col>
                  </Row>
                </Form>
              </ModalBody>
            </Modal>
          </Card>
          {/* <SweetAlert success title="Registration Successful"
          show={this.state.successAlert}
          onConfirm={() => this.handleAlert("successAlert", false)}
        >
        </SweetAlert> */}
        </Col>
      </Row>

    )
  }
}

export default QuestionsList
