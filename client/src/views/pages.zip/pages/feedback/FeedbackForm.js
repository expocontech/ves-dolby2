import React, { Component } from "react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Row,
  Col,
  Button,
  Form,
  Input,
  Label,
  FormGroup,
  Table
} from "reactstrap"
import Checkbox from "../../../components/@vuexy/checkbox/CheckboxesVuexy"
import { Check, Lock } from "react-feather"
import axios from "axios"
import { history } from "../../../../src/history"
class FeedbackForm extends React.Component {

  state = {
    fb: '',
    ressage: '',
    fmessage: ''
  }


  handleAddFeedback = (e) => {
    e.preventDefault();
    if (this.state.fb == '') {
      this.setState({
        fb: '',
        fmessage:'Please write a feedback!',
        rmessage: ''
      })
    }
    else {
      const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
      const uid = sessionStorage.getItem('uid').toString();
      const data = { "uidval": uid, "feedbackval": this.state.fb };
      axios.post(`${process.env.REACT_APP_BASENAME}feedback`, data, { headers: authHeader }).then(
        (response) => {
          console.log("response", response);
          this.setState({
            fb: '',
            rmessage: "Your feedback is submitted",
            fmessage: ''
          })
        }
      ).catch((error) => {
        history.push('/')
      })
    }
  }
  render() {
    return (
      <Card>
        <CardBody>
          <Row>
            <Col sm="12">
              <Form action="/pages/feedback" onSubmit={this.handleAddFeedback}>
                <Row>
                  <Col md="12" sm="12">
                    <span className="text-success">{this.state.rmessage}</span>
                    <span className="text-danger">{this.state.fmessage}</span>
                    <FormGroup>
                      <Label for="mobile">Comments</Label>
                      <Input type="textarea" id="Comments" rows="6" placeholder="Comments" value={this.state.fb} onChange={e => this.setState({ fb: e.target.value })} />
                    </FormGroup>
                  </Col>
                  <Col
                    className="d-flex justify-content-end flex-wrap" sm="12" >
                    <Button.Ripple className="" color="primary" type="submit">Submit</Button.Ripple>
                  </Col>
                </Row>
              </Form>
            </Col>
          </Row>
        </CardBody>
      </Card>
    )
  }
}
export default FeedbackForm
