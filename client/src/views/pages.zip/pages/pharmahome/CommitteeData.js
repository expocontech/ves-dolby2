import img1 from "../../../assets/img/pages/committee/1.jpg"
import img2 from "../../../assets/img/pages/committee/2.jpg"
import img3 from "../../../assets/img/pages/committee/3.jpg"
import img4 from "../../../assets/img/pages/committee/4.jpg"
import img5 from "../../../assets/img/pages/committee/1.jpg"
import img6 from "../../../assets/img/pages/committee/2.jpg"
import img7 from "../../../assets/img/pages/committee/3.jpg"
import img8 from "../../../assets/img/pages/committee/4.jpg"

export const data = [
  {
    id: 1,
    img: img1,
    title: "dr. ashraf ganie",
    text: "President MPPCOS Society"
  },
  {
    id: 2,
    img: img2,
    title: "dr. rakesh sahay",
    text: "Organising Chairman"
  },
  {
    id: 3,
    img: img3,
    title: "dr. sanjay kalra",
    text: "Chairman Scientific Committee"
  },
  {
    id: 4,
    img: img4,
    title: "dr. jayaprakash sai",
    text: "Organising Secretary"
  },
  {
    id: 5,
    img: img1,
    title: "dr. ashraf ganie",
    text: "President MPPCOS Society"
  },
  {
    id: 6,
    img: img2,
    title: "rakesh sahay",
    text: "Organising Chairman"
  },
  {
    id: 7,
    img: img3,
    title: "dr. sanjay kalra",
    text: "Chairman Scientific Committee"
  },
  {
    id: 8,
    img: img4,
    title: "dr. jayaprakash sai",
    text: "Organising Secretary"
  }
]
