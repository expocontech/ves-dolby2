import React from "react"
import {
  Card,
  CardHeader,
  CardTitle,
  CardBody,
  Modal,
  Row,
  Col,
  ModalHeader,
  ModalBody,Form,Button
} from "reactstrap"

import * as Icon from "react-feather"
import { Link } from "react-router-dom"
//import Checkbox from "../../../components/@vuexy/checkbox/CheckboxesVuexy"
import "../../../assets/scss/pages/users.scss"
import speakerimg2 from "../../../assets/img/pages/committee/2.jpg"
import speakerimg3 from "../../../assets/img/pages/committee/3.jpg"
import speakerimg4 from "../../../assets/img/pages/committee/4.jpg"
import programme1 from "../../../assets/img/programme/1.jpeg"
class Programme extends React.Component {

  state = {
    modal: false
  }

  componentDidMount() {
    this.fetchProgramme()
  }

  fetchProgramme = () => {
    const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
    fetch(`${process.env.REACT_APP_BASENAME}programme/`, { headers: authHeader }).then(results => {
      return results.json();
    }).then(data => {
      console.log(data);
      this.setState({
        title: data.result[0].title,
        img: `${process.env.REACT_APP_BASENAME}`+data.result[0].image,
        pdf: `${process.env.REACT_APP_BASENAME}`+data.result[0].pdf
      });
    })
  }

  toggleModal = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }))
  }



  render() {
    return (
      <React.Fragment>
        <Card className="mt-1">
            <CardBody className="knowledge-base-bg">
              <h1 className="white">Programme</h1>
            </CardBody>
          </Card>
        <Row>
          <Col sm="1" md="1"></Col>
          <Col sm="10" md="10">
            <Card>
              <CardBody>
                      <div className="d-flex justify-content-between">
              <Button.Ripple color="primary" type="submit" style={{display: "none"}}>Register Now</Button.Ripple>
            <a href={this.state.pdf} target="_blank"><Button.Ripple color="primary" >Download PDF</Button.Ripple></a>
              </div>
              <img src={this.state.img} className="mx-auto mb-1" width="100%" />
              </CardBody>
            </Card>
          </Col>

          {/* <Modal isOpen={this.state.modal} toggle={this.toggleModal} className="modal-dialog-centered modal-lg" >
            <ModalHeader toggle={this.toggleModal}>
            Faculty Details
            </ModalHeader>
            <ModalBody>
            <Form>
            <Row >
          <Col md="12" sm="12" xs="12">

          <div className="d-flex justify-content-start align-items-center mb-1">
              <div className="avatar mr-1">
                <img src={speakerimg2} alt="avtar img holder" height="120" width="120"
                />
              </div>
              <div className="user-page-info">
                  <h4>DR. RAKESH SAHAY</h4>
                <span className="font-small-2">MBBS, DM - Endocrinology, DNB - General Medicine</span><br/>
                <span className="font-small-2">AIIMS, Apollo, Osmania Medical Collage</span>
              </div>
            </div>
            <div style={{border: "2px solid #f8f8f8"}}>
              <h5 style={{background: "#deb887", padding: "10px"}}>Chair of</h5>
                <div style={{padding: "10px", borderBottom: "2px solid #f8f8f8"}}>
                    <span className="float-left"><b><Icon.Clock size={20} /> 10.20 - 11.00</b></span>
                    <span className="float-right"><b><Icon.Calendar size={20} /> 04/02/2021</b></span><br/>
                    <h4 style={{lineHeight: "1.5", marginBottom: "0px", marginTop: "10px"}}><b>Meet the who civil society task force at the 50th union conference</b></h4>
                </div>
                <div style={{padding: "10px", borderBottom: "2px solid #f8f8f8"}}>
                    <span className="float-left"><b><Icon.Clock size={20} /> 10.20 - 11.00</b></span>
                    <span className="float-right"><b><Icon.Calendar size={20} /> 04/02/2021</b></span><br/>
                    <h4 style={{lineHeight: "1.5", marginBottom: "0px", marginTop: "10px"}}><b>Meet the who civil society task force at the 50th union conference</b></h4>
                </div>
                <div style={{padding: "10px", borderBottom: "2px solid #f8f8f8"}}>
                    <span className="float-left"><b><Icon.Clock size={20} /> 10.20 - 11.00</b></span>
                    <span className="float-right"><b><Icon.Calendar size={20} /> 04/02/2021</b></span><br/>
                    <h4 style={{lineHeight: "1.5", marginBottom: "0px", marginTop: "10px"}}><b>Meet the who civil society task force at the 50th union conference</b></h4>
                </div>
            </div>
            <div style={{border: "2px solid #f8f8f8"}}>
              <h5 style={{background: "#deb887", padding: "10px"}}>Speaker of</h5>
                <div style={{padding: "10px", borderBottom: "2px solid #f8f8f8"}}>
                    <span className="float-left"><b><Icon.Clock size={20} /> 10.20 - 11.00</b></span>
                    <span className="float-right"><b><Icon.Calendar size={20} /> 04/02/2021</b></span><br/>
                    <h4 style={{lineHeight: "1.5", marginBottom: "0px", marginTop: "10px"}}><b>Asia Pacific progress and partnering with technical agencies for accountability</b></h4>
                    <h6 style={{marginTop: "10px"}}>Mr. Shaik Basheeruddin</h6>
                </div>
                <div style={{padding: "10px", borderBottom: "2px solid #f8f8f8"}}>
                    <span className="float-left"><b><Icon.Clock size={20} /> 10.20 - 11.00</b></span>
                    <span className="float-right"><b><Icon.Calendar size={20} /> 04/02/2021</b></span><br/>
                    <h4 style={{lineHeight: "1.5", marginBottom: "0px", marginTop: "10px"}}><b>Asia Pacific progress and partnering with technical agencies for accountability</b></h4>
                    <h6 style={{marginTop: "10px"}}>Mr. Shaik Basheeruddin</h6>
                </div>
                <div style={{padding: "10px", borderBottom: "2px solid #f8f8f8"}}>
                    <span className="float-left"><b><Icon.Clock size={20} /> 10.20 - 11.00</b></span>
                    <span className="float-right"><b><Icon.Calendar size={20} /> 04/02/2021</b></span><br/>
                    <h4 style={{lineHeight: "1.5", marginBottom: "0px", marginTop: "10px"}}><b>Asia Pacific progress and partnering with technical agencies for accountability</b></h4>
                    <h6 style={{marginTop: "10px"}}>Mr. Shaik Basheeruddin</h6>
                </div>
            </div>
</Col>
              </Row>
              </Form>
          </ModalBody>
        </Modal> */}
        </Row>
      </React.Fragment>
    )
  }
}
export default Programme
