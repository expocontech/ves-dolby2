import logo from "../../../assets/img/pages/sponsor/logo.png"
import banner from "../../../assets/img/logo/banner.jpg" 
//import video from "https://www.youtube.com/embed/3dSXSkWmJ24" 

export const data = [
  {
    id: 1,
    img: logo,
    title: "digital diabetes summit",
    institute: "Diamond Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 2,
    img: logo,
    title: "digital diabetes summit",
    institute: "Platimum Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 3,
    img: logo,
    title: "digital diabetes summit",
    institute: "Gold Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 4,
    img: logo,
    title: "digital diabetes summit",
    institute: "Silver Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 5,
    img: logo,
    title: "digital diabetes summit",
    institute: "Gold Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 6,
    img: logo,
    title: "digital diabetes summit",
    institute: "Gold Sponsor",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 7,
    img: logo,
    title: "digital diabetes summit",
    institute: "Gold",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  },
  {
    id: 8,
    img: logo,
    title: "digital diabetes summit",
    institute: "Gold",
    banner: banner,
    video: "https://www.youtube.com/embed/3dSXSkWmJ24"
  }
]
