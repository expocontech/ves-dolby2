import React from "react"
import { Row, Col } from "reactstrap"
import SponsorMain from "./SponsorMain"
import "../../../assets/scss/pages/knowledge-base.scss"

class Sponsor extends React.Component {
  render() {
    return (
      <React.Fragment>
        <Row>
          <Col sm="12">
            <SponsorMain />
          </Col>
        </Row>
      </React.Fragment>
    )
  }
}

export default Sponsor
