import React from "react"
import { Card, CardBody, Row, Col, Button, Form, Label, FormGroup, Modal, ModalHeader, ModalBody, Input } from "reactstrap"
// import { Link } from "react-router-dom"
import { data } from "./SponsorData"
import falimg from "../../../assets/img/pages/sponsor/logo.png"
import banner from "../../../assets/img/logo/banner.jpg"
import axios from "axios"
import {history} from "../../../history"
class SponsorDesign extends React.Component {

  state = {
    modal: false,
    data: []
  }

  toggleModal = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }))
  }

  handleReadmore = (sid) =>{
    console.log("sponsor id",sid)
    sessionStorage.setItem('spid',sid)
    if(sessionStorage.getItem('spid') != '')
    {
      history.push('/pages/sponsordetails')
    }
  }

  componentDidMount = () => {

    if (sessionStorage.getItem('token') != null) {
      const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
      axios.get(`${process.env.REACT_APP_BASENAME}sponsor`, { headers: authHeader }).then(
        response => {
          console.log(response.data);
          this.setState({
            data: response.data.result
          });
        }
      ).catch((error) => {

      });
    }
    else {
      history.push('/')
    }

  }

  renderCards = () => {
    let result = this.state.data.map(item => {
      if (this.props.value.length < 1) {
        return (
          <Col md="3" sm="12" xs="12" className="search-content" key={item.id}>
            <Card>
              <CardBody className="text-center">
                <img
                  src={`${process.env.REACT_APP_BASENAME}` + item.logo}
                  alt={item.company}
                  className="mx-auto mb-2"
                  width="100%"
                />
                <h5>{item.company.toUpperCase()}</h5>
                <p className="text-dark">{item.type}</p>
                <Button.Ripple className="btn-block gradient-light-primary" onClick={() => this.handleReadmore(item.id)}>
                    Read More
                  </Button.Ripple>
              </CardBody>
            </Card>
          </Col>

        )
      } else if (item.company.includes(this.props.value)) {
        return (
          <Col md="3" sm="12" xs="12" className="search-content" key={item.id}>
            <Card>
              <CardBody className="text-center">
                <img
                  src={`${process.env.REACT_APP_BASENAME}` + item.logo}
                  alt={item.company}
                  className="mx-auto mb-2"
                  width="100%"
                />
                <h5>{item.company.toUpperCase()}</h5>
                <p className="text-dark">{item.type}</p>
                <Button.Ripple className="btn-block gradient-light-primary" onClick={() => this.handleReadmore(item.id)}>
                    Read More
                  </Button.Ripple>
              </CardBody>
            </Card>
          </Col>
        )
      }
      return ""
    })
    return result
  }
  render() {
    return <Row>{this.renderCards()}
      {/* <Modal isOpen={this.state.modal} toggle={this.toggleModal} className="modal-dialog-centered modal-lg" >
        <ModalHeader toggle={this.toggleModal}>
          Digital Diabetes Summit, Gold Sponsor
            </ModalHeader>
        <ModalBody className="text-center">
          <Form>
            <Row >
              <Col md="12" sm="12" xs="12" style={{ margin: "0 auto" }}>
                <img src={falimg} className="text-center" width="250" style={{ float: "left", height: "auto" }} />
              </Col>
              <Col className="mt-2">
                <img src={banner} width="100%" />
              </Col>
              <Col md="12" sm="12" xs="12" className="mt-2">
                <Card className="overflow-hidden">
                  <div className="embed-responsive embed-responsive-16by9">
                    <iframe
                      width="100%"
                      height="315"
                      src="https://www.youtube.com/embed/3dSXSkWmJ24"
                      frameBorder="0"
                      allow="accelerometer autoplay encrypted-media gyroscope picture-in-picture"
                      allowFullScreen
                      title="video"
                    />
                  </div>
                </Card>
              </Col>
            </Row>
          </Form>
        </ModalBody>
      </Modal> */}

    </Row>

  }
}
export default SponsorDesign
