import React from "react"
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  TabContent,
  TabPane,
  Nav,
  NavItem,
  NavLink,
  Input,
  Label,
  Form,
  FormGroup
} from "reactstrap"
import classnames from "classnames"
import { Eye, Code } from "react-feather"
import { FaSignal } from "react-icons/fa";
import * as Icon from "react-feather"
import { history } from "../../../../src/history"
import Radio from "../../../components/@vuexy/radio/RadioVuexy"
import axios from "axios"

class Polls extends React.Component {
  state = {
    activeTab: "1",
    modal: false,
    question: '',
    o1: '',
    o2: '',
    o3: '',
    o4: '',
    res: '',
    queid: '',
    id:'',
    message: ''
  }

  toggleModal = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }))
  }


  handlePolls = (e) => {
    e.preventDefault();
    if (this.state.res != '') {
      const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
      const uid = sessionStorage.getItem('uid').toString();
      console.log("question id",this.state.id)
      const data = { "uidval": uid, "result": this.state.res, "queid": this.state.id };
      axios.post(`${process.env.REACT_APP_BASENAME}poll/result`, data, { headers: authHeader }).then(
        (response) => {
          console.log("response", response);
          this.setState({
            res: '',
            message: "Polls submitted"
          })
          this.toggleModal()
        }
      ).catch((error) => {
        console.log("error", error);
        history.push('/')
      })
    }
    else {
      this.setState({
        message: "Select Any Option"
      })
    }
  }

  componentDidMount = () => {
    if (sessionStorage.getItem('token') != null) {
      const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
      axios.get(`${process.env.REACT_APP_BASENAME}poll/question`, { headers: authHeader }).then(
        response => {
          console.log(response.data);
          this.setState({
            id: response.data.result[0].id,
            question: response.data.result[0].question,
            o1: response.data.result[0].o1,
            o2: response.data.result[0].o2,
            o3: response.data.result[0].o3,
            o4: response.data.result[0].o4
          });
        }
      ).catch((error) => {
        console.log(error)
        history.push('/')
      });
    }
    else {
      history.push('/');
    }
  }

  render() {
    return (
      <React.Fragment>
        <Form inline onSubmit={e => e.preventDefault()}>
          <Button color="primary" className="btn-icon mr-1"
            onClick={this.toggleModal}>
            <FaSignal /> Polls
              </Button>

        </Form>
        <Modal
          isOpen={this.state.modal}
          toggle={this.toggleModal}
          className={this.props.className} className="modal-dialog-centered" >

          <ModalHeader toggle={this.toggleModal}>
            Polls
                  </ModalHeader>
          <span className="text-danger">{this.state.message}</span>
          <Form onSubmit={this.handlePolls}>
            {/* <input type="hidden" value={th onChange={e => this.setState({ queid: e.target.value })} /> */}
            <ModalBody>
              <p>{this.state.question}</p>
              <Radio
                label={this.state.o1}
                color="primary"
                defaultChecked={false}
                name="exampleRadioSizes"
                value="o1"
                onChange={e => this.setState({ res: e.target.value })}
                className="py-50"
              />
              <Radio
                label={this.state.o2}
                color="primary"
                defaultChecked={false}
                name="exampleRadioSizes"
                value="o2"
                onChange={e => this.setState({ res: e.target.value })}
                className="py-50"
              />
              <Radio
                label={this.state.o3}
                color="primary"
                defaultChecked={false}
                name="exampleRadioSizes"
                value="o3"
                onChange={e => this.setState({ res: e.target.value })}
                className="py-50"
              />
              <Radio
                label={this.state.o4}
                color="primary"
                defaultChecked={false}
                name="exampleRadioSizes"
                value="o4"
                onChange={e => this.setState({ res: e.target.value })}
                className="py-50"
              />
              <br />
              <Button.Ripple type='submit' color="success">
                Submit
              </Button.Ripple>
            </ModalBody>
          </Form>
        </Modal>
      </React.Fragment>
    )
  }
}
export default Polls
