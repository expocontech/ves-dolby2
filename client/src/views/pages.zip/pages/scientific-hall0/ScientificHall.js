import React from "react"
import { Row, Col } from "reactstrap"
import ProfileHeader from "./ProfileHeader"


import "../../../assets/scss/pages/users-profile.scss"

class ScientificHall extends React.Component {
  state = {
    isLoading: false
  }

  toggleLoading = () => {
    this.setState({
      isLoading: true
    })

    setTimeout(() => {
      this.setState({
        isLoading: false
      })
    }, 2000)
  }

  render() {
    return (
      <React.Fragment>
        <div id="user-profile">
              <ProfileHeader />
          {/* <Row>
            <Col sm="12">
            </Col>
          </Row> */}
          {/* <div id="profile-info">
            <Row>
              <Col lg="8" md="12">
                <AboutCard />
              </Col>
              <Col lg="4" md="12">
                <SuggestedPages />
              </Col>
              <Col lg="8" md="12">
                <Posts />
              </Col>
              <Col lg="4" md="12">
                <Videos />
              </Col>
            </Row>
          </div> */}
        </div>
      </React.Fragment>
    )
  }
}

export default ScientificHall
