import React from "react"
import { Card, CardBody, Button, Modal, ModalHeader, ModalBody, Input, ModalFooter, Form, Row, Col } from "reactstrap"
//import { Edit2, Settings, Video, Menu, X } from "react-feather"
//import coverImg from "../../../assets/img/sponsor/bgimg.jpg"
//import leftsideImg from "../../../assets/img/sponsor/liftsidebgimg.jpg"
//import coverImg1 from "../../../assets/img/sponsor/bgimg1.jpg"
import coverImg1 from "../../../assets/img/sponsor/MainHall11.jpg"
//import profileImg from "../../../assets/img/sponsor/4.jpg"
import * as Icon from "react-feather"
import AskQuestion from "./AskQuestion"
import Agenda from "./Agenda"
import AttendeeList from "./AttendeeList"
import Polls from "./Polls"
import { GoReport } from "react-icons/go";
import { history } from "../../../history"
import axios from "axios"
class ProfileHeader extends React.Component {
  state = {
    modal: false,
    link:'',
    backbanner:'',
    pollstatus:'',
    astatus:''
  }

  toggleModal = () => {
    this.setState(prevState => ({
      modal: !prevState.modal
    }))
}

componentDidMount() {
  // console.log("question state", this.state.question)
  // console.log("After question submit redirect");
  if (sessionStorage.getItem('token') != null) {
  const authHeader = { 'Authorization': 'Bearer ' + sessionStorage.getItem('token').toString() };
  fetch(`${process.env.REACT_APP_BASENAME}viewlive/`, { headers: authHeader }).then(results => {
    return results.json();
  }).then(data => {
    console.log(data);
    this.setState({
      link: data.result[0].livelink,
      backbanner: `${process.env.REACT_APP_BASENAME}` + data.result[0].backbanner
    });
  })
  }
  else {
    history.push('/')
  }

  axios.get(`${process.env.REACT_APP_BASENAME}eventsetting`).then(
    (response) => {

      if (response.data.status == true) {
        var pollstat
        if (response.data.pollbutton == 1) {
          pollstat = true
        }
        else {
          pollstat = false
        }

        var astat
        if (response.data.attendeebutton == 1) {
          astat = true
        }
        else {
          astat = false
        }
        this.setState({
          pollstatus: pollstat,
          astatus:astat
        })
      }

    }
  ).catch((error) => {
    history.push('/')
    this.setState({
      message: "Some error in Server"
    })
  })
}
  render() {
    return (
      <Card>
        <CardBody>
      <div className="profile-header">
        <div className="position-relative">
          <div className="cover-container" style={{position: "absolute", left: "26.95%", width: "46%", height: "51.4%", top: "29.1%", cursor: "pointer"}} >
          <iframe
              className="embed-responsive-item w-100"
              src={this.state.link}
              allowFullScreen
              title="post"
              frameBorder="0"
              height= "100%"
            />
          </div>
          <div className="cover-container">
            <img
              src={this.state.backbanner}
              alt="CoverImg"
              className="img-fluid bg-cover w-100 rounded-0"
            />
          </div>

          <div className="profile-img-container d-flex align-items-center justify-content-between">
         <AskQuestion/>
         {this.state.pollstatus ? <Polls/> : null}
         {this.state.astatus ? <AttendeeList/> : null}
         {/* <AttendeeList/> */}
         <Agenda/>

          </div>
        </div>
      </div>
        </CardBody>
      </Card>
    )
  }
}
export default ProfileHeader
