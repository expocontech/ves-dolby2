import React from "react"
import { Modal, Button,  ModalHeader, ModalBody, Table } from "reactstrap"
import { FaUsers, FaVideo } from "react-icons/fa";
import ViewVideo from "./ViewVideo"

class VideoList extends React.Component {
    state = {
        modal: false 
    }
    toggleModal = () => {
        this.setState(prevState => ({
          modal: !prevState.modal
        }))
      }

  render() {
    return  (
        <React.Fragment>                 
      <Button color="primary" className="btn-icon mr-1"
            onClick={this.toggleModal}>
        <FaVideo /> Videos
      </Button> 

                <Modal
                  isOpen={this.state.modal}
                  toggle={this.toggleModal}
                  className={this.props.className} className="modal-dialog-centered modal-lg" >
                  <ModalHeader toggle={this.toggleModal}>
                  Video List
                  </ModalHeader>
                  <ModalBody>
      <Table responsive>
        <tbody>
          <tr>
            <th scope="row"><FaVideo size={24} /></th>
            <td> <ViewVideo /></td>
            <td> Jardiance & Jardiance Met </td>
          </tr>
          <tr>
            <th scope="row"><FaVideo size={24} /></th>
            <td> <ViewVideo /></td>
            <td> Jardiance & Jardiance Met </td>
          </tr>
          <tr>
            <th scope="row"><FaVideo size={24} /></th>
            <td> <ViewVideo /></td>
            <td> Jardiance & Jardiance Met </td>
          </tr>
          <tr>
            <th scope="row"><FaVideo size={24} /></th>
            <td> <Button.Ripple className="mr-1" color="relief-dark">View</Button.Ripple></td>
            <td> Jardiance & Jardiance Met </td>
          </tr>
        </tbody>
      </Table>
      </ModalBody>      
      </Modal>
      </React.Fragment>
    )
  }
}
export default VideoList