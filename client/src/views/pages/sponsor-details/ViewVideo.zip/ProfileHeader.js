import React from "react"
import { Card, CardBody, Button} from "reactstrap"
import { Edit2, Settings, Video, Menu, X } from "react-feather"
import coverImg from "../../../assets/img/sponsor/banner.jpg"
import profileImg from "../../../assets/img/pages/sponsor/intas.jpg"
import DocList from "./DocList"
import VideoList from "./VideoList" 
import CallUs from "./CallUs" 
import AboutCard from "./AboutCard"
import RequestDemo from "./RequestDemo"  

class ProfileHeader extends React.Component {
  state = {
    isOpen: false
  }

  toggle = () => {
    this.setState({
      isOpen: !this.state.isOpen
    })
  }
  render() {
    return (
      <Card>
        <CardBody>
      <div className="profile-header">
        <div className="position-relative">
          <div className="cover-container">
            <img
              src={coverImg}
              alt="CoverImg"
              className="img-fluid bg-cover w-100 rounded-0"
            />
          </div>
          <div className="profile-img-container d-flex align-items-center justify-content-between" style={{bottom:"-1rem"}}>

              <AboutCard />
              <CallUs />
              <DocList />
              <VideoList />
              <RequestDemo />
          </div>
        </div>
      </div>
      </CardBody>
      </Card>
    )
  }
}
export default ProfileHeader
