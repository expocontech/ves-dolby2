import React from "react"
import { Modal, ModalHeader, ModalBody, Card, CardHeader, CardTitle, CardBody, Button } from "reactstrap"
import SweetAlert from 'react-bootstrap-sweetalert';
import { FaInfoCircle } from "react-icons/fa";

class RequestDemo extends React.Component {
    state = {
     successAlert : false, 
     errorAlert : false, 
     infoAlert : false, 
     warningAlert : false
    }
  
    handleAlert = (state, value) => {
      this.setState({ [state] : value })
    }
  render() {
    return ( 
      <React.Fragment>                 
    <Button color="primary" className="btn-icon mr-1" onClick={() => this.handleAlert("successAlert", true)}>  <FaInfoCircle /> Request Demo</Button> 
        <SweetAlert success title="Success" show={this.state.successAlert} onConfirm={() => this.handleAlert("successAlert", false)} >
          <p className="sweet-alert-text">Our Team will get back to you!</p>
      </SweetAlert>
      </React.Fragment>
    )
  }
}
export default RequestDemo
