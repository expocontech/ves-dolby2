import React from "react"
import { Modal, ModalHeader, ModalBody, Card, CardHeader, CardTitle, CardBody, Button } from "reactstrap"
import { MoreHorizontal, Facebook, Instagram, Twitter } from "react-feather"
import { FaInfoCircle } from "react-icons/fa";

class AboutCard extends React.Component {
  state = {
      modal: false 
  }
  toggleModal = () => {
      this.setState(prevState => ({
        modal: !prevState.modal
      }))
    }
  render() {
    return ( 
      <React.Fragment>                 
    <Button color="primary" className="btn-icon mr-1"
          onClick={this.toggleModal}>
      <FaInfoCircle /> About Us
    </Button> 

              <Modal
                isOpen={this.state.modal}
                toggle={this.toggleModal}
                className={this.props.className} className="modal-dialog-centered modal-lg" >
                <ModalHeader toggle={this.toggleModal}>
                About Us
                </ModalHeader>
                <ModalBody>
      <Card>
        <CardHeader>
          <CardTitle>About Us</CardTitle>
          <MoreHorizontal size={15} className="cursor-pointer" />
        </CardHeader>
        <CardBody>
          <p className="text-justify">Intas is one of the leading multinational pharmaceutical formulation development, manufacturing and marketing companies in the world. Today, Intas is present in more than 85 countries worldwide and is growing at ~20% CAGR. Around 70% of its revenues come from the international markets, particularly the highly regulated markets of EU and US. At Intas, every day and everyone works to create a world of good health, happiness and hope.
Intas is one of the leading multinational pharmaceutical formulation development, manufacturing and marketing companies in the world. Today, Intas is present in more than 85 countries worldwide and is growing at ~20% CAGR. Around 70% of its revenues come from the international markets, particularly the highly regulated markets of EU and US. At Intas, every day and everyone works to create a world of good health, happiness and hope.          </p>
          <div className="mt-1">
            <h6 className="mb-0">Email: <a href="mailto:generalqueries@intaspharma.com">generalqueries@intaspharma.com</a></h6>
          </div>
          <div className="mt-1">
            <h6 className="mb-0">Website: <a href="https://intaspharma.com/" target="_blank">www.intaspharma.com</a></h6>
          </div>
        </CardBody>
      </Card>
      </ModalBody>      
      </Modal>
      </React.Fragment>
    )
  }
}
export default AboutCard
